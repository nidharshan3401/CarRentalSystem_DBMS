<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Cars</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/perfect-scrollbar/perfect-scrollbar.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main2.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-table100">
			<div class="wrap-table100">
				<div class="table100">
				<!--<h1 style="text-align:center";>CARS LIST</h1>-->
					<table>
						<thead>
							<tr class="table100-head">
                            <th class="column1">Car_Id</th>
<th class="column2"> Car_name</th>
<th class="column3">Car_No</th>
<th class="column4">Category</th>
<th class="column5">Type</th>
<th class="column6">Rate/km</th>
							</tr>
						</thead>
						<tbody>
						<?php
    $conn = OpenCon();
    $sql = "SELECT * FROM car";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td class=column1>" . $row["Car_id"]. "</td><td class=column2>" . $row["Car_name"] . "</td><td class=column3>". $row["Car_no"]. "</td><td class=column4>" . $row["category"]. "</td><td class=column5>" . $row["type"]. "</td><td class=column6>" . $row["rate_per_km"]. "</td></tr>";}
            echo "</table>";
        }   
        else { echo "0 results"; }
        CloseCon($conn);
?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>


	

<!--===============================================================================================-->	
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="js/main.js"></script>

</body>
</html>