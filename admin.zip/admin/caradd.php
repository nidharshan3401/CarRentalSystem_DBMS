<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>carform</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body style="background-color:#E6E6FA;"><nav class="navbar navbar-light navbar-expand-md" >
        <div class="container-fluid"><a class="navbar-brand" href="#">ADD CAR</a></div>
    </nav>
    <form data-bss-recipient="ed303353e0b20b3026567d0fe0c6a906" method="POST">
        <div class="form-group">
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Car ID" required="" name="car_id"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Car Name" required="" name="car_name"></div>
            </div>
            <div class="form-row" style="text-align: center;height: 50px;">
                <div class="col" style="text-align: center;"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Car Type" required="" name="car_type"></div>
            </div>
            <div class="form-row" style="text-align: center;height: 50px;">
                <div class="col" style="text-align: center;"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Category" required="" name="car_category"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="number" placeholder="rate/km" required="" name="car_rate"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col"><input class="border rounded-0 border-dark form-control" type="text" placeholder="Car Reg No." required="" name="car_reg"></div>
            </div>
            <div class="form-row" style="height: 50px;">
                <div class="col text-center"><input name="addcar" class="btn btn-primary" type="submit" style="width: 100px;height: 40px;" value="ADD CAR"></input></div>
            </div>
        </div>
        
        <?php
            //CAR ADD
            $conn = OpenCon();

            if(isset($_POST['addcar'])){
            $sql = "INSERT INTO car(Car_id,Car_name,Car_no,category,type,rate_per_km) VALUES(?,?,?,?,?,?)";
            
            $car_id = $_POST['car_id'];
            $car_name = $_POST['car_name'];
            $car_reg = $_POST['car_reg'];
            $car_category = $_POST['car_category'];
            $car_type = $_POST['car_type'];
            $car_rate = $_POST['car_rate'];
            
            $stmt = mysqli_prepare($conn,$sql);
            $stmt->bind_param("ssssss",$car_id,$car_name,$car_reg,$car_category,$car_type,$car_rate);

            if(mysqli_stmt_execute($stmt)){
                echo '<script type="text/JavaScript">  
                alert("Car added successfully !! "); 
                </script>' ; 
            }
            
            Closecon($conn);
            }
        ?>

    </form>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.bundle.min.js"></script>
</body>

</html>