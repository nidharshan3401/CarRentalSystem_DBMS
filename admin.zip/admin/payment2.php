<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");

    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>

<?php
    $conn = OpenCon();
    $row = $conn->query("SELECT Payment_id FROM payment ORDER BY Payment_id DESC LIMIT 1;");
    while ($X = mysqli_fetch_assoc($row)){
        $p_id = $X['Payment_id'];
    }

    //Declaration of variables
    $discount_applied = null;
    $balance = 0;
    $total = 0;
    $sum = 0;
    $c_id = null;
    $b_id = 0;

    $row = $conn->query("SELECT * FROM payment where Payment_id='$p_id'");
    while ($X = mysqli_fetch_assoc($row)){
        $discount_applied = $X['discount_applied'];
        $balance = $X['balance'];
        $total = $X['total'];
        $b_id = $X['booking_ref_id'];
    }

    $str = " ";
    if($discount_applied==1){
        $sum = $balance;
        $str = "Yes";
        
    }
    else{    
        $sum = $total;
        $str = "No";}
    
    $result = $conn->query("SELECT cust_ref_id from booking WHERE Booking_id='$b_id'");
    while ($X = mysqli_fetch_assoc($result)){
        $c_id = $X['cust_ref_id'];
    }
    $points = $sum/100;
    $sql1 = "SELECT cust_ref_id FROM payment_points WHERE cust_ref_id='$c_id' ";
    $stmt = mysqli_prepare($conn, $sql1);
    $stmt->execute();
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt) == 1){                    
        $sql4 = "UPDATE payment_points SET points=$points where cust_ref_id='$c_id'";
        $stmt1 = mysqli_prepare($conn,$sql4);
        $stmt1->execute();
    }

        else{
            $sql = "INSERT INTO payment_points VALUES(?,?)";
            $stmt = mysqli_prepare($conn,$sql);
            $stmt->bind_param("ss",$c_id,$points);
            $stmt->execute();        }



    if($str=="Yes"){
        $sql4 = "UPDATE customer SET points='$points' where Cust_id='$c_id'";
        $stmt1 = mysqli_prepare($conn,$sql4);
        $stmt1->execute();
    }
    else{
        $p = 0;
        $result = $conn->query("SELECT points from customer WHERE Cust_id='$c_id'");
        while ($X = mysqli_fetch_assoc($result)){
            $p = $X['points'];
        }
        $points = $p+$points;
        $sql4 = "UPDATE customer SET points='$points' where Cust_id='$c_id'";
        $stmt1 = mysqli_prepare($conn,$sql4);
        $stmt1->execute();
    }
    

?>
<!DOCTYPE html>
<html>
<head>
<title>Reciept</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<h2>PAYMENT BILL  :</h2>
<table>
<tr>
<th>Payment_Id</th>
<th>Cust_Id</th>
<th>Booking_id</th>
<th>Amt Paid</th>
<th>AppliedDiscount</th>
</tr>
<?php
    $row = $conn->query("SELECT * FROM payment where Payment_id='$p_id'");
    if ( ($row->num_rows)> 0) {
        // output data of each row
        while($row1 = $row->fetch_assoc()) {
            echo "<tr><td>" . $row1["Payment_id"]. "</td><td>" . $row1["cust_ref_id"] . "</td><td>". $row1["booking_ref_id"]. "</td><td>" . $sum. "</td><td>" . $str. "</td><td>" . "</td></tr>";}
            echo "</table>";
        }   
        else { echo "0 results"; }
        CloseCon($conn);
?>
</table>
    <br><br><br><br>
    <div class="form-row" style="height: 50px;">
        <div class="col text-center"><button name="pay" class="btn btn-primary" onclick=window.location.href="mainadmin.php"  style="width: 100px;height: 40px; ">HOME</button></div>
    </div>
</body>
</html>