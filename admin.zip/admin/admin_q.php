<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: ../Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Unanswered</title>
    <link rel="stylesheet" href="query/assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="query/assets/css/styles.css">
</head>

<body style="background: rgb(247,139,139);">
    <div>
        <header>
            <p style="font-size: 35px;text-align: center;"><strong><em>Unanswered Queries</em></strong></p>
        </header>
    </div>
    <form method="POST">
        <div class="form-group text-center">
            <p style="text-align: center;font-size: 20px;">Queries</p>
            <p style="text-align: center;font-size: 20px;"></p>
            <div class="text-center" style="text-align: center;margin-right: 100px;margin-left: 300px;width: 600px;"><select name="query" class="form-control" style="width: 550px;text-align: center;margin: 20px; margin-left: 200px;">
            <?php
                $conn = OpenCon();
                $records = $conn->query("SELECT cust_query FROM query where reply_admin='Not yet answered'");
                while ($car = mysqli_fetch_assoc($records)){
                echo "<option>".$car['cust_query']."</option>";
                }
                CloseCon($conn);
            ?>
    </select>

            </select></div>
            <p
                style="text-align: center;font-size: 20px;">Answer</p><input name="answer" type="text" class="form-control form-control-lg">
                <p style="text-align: center;font-size: 20px;"></p><button name="SUBMIT" class="btn btn-primary" type="submit" style="background: rgb(174,251,181);color: rgb(0,0,0);">Submit</button></div>
                <input type="button" class="btn btn-primary" value="HOME" onclick="window.location.href='mainadmin.php';" style="background: rgb(174,251,181);color: rgb(0,0,0); position: absolute; left: 732px;">
                <?php
                $conn = OpenCon();
                    if(isset($_POST['SUBMIT'])){
                        $var1 = $_POST['query'];
                        $var2 = $_POST['answer'];
                        $sql = "UPDATE query SET reply_admin='$var2' where cust_query='$var1'";
                        $stmt1 = mysqli_prepare($conn,$sql);
                        $stmt1->execute();

                        echo '<script type="text/JavaScript">  
                        alert("Query answered !! "); 
                        </script>' ;
                        header("Refresh:0");
                    }
                CloseCon($conn);
                ?>
    </form>
    <script src="query/assets/js/jquery.min.js"></script>
    <script src="query/assets/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>