<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html>
<head>
<title>Cars</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #588c7e;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #588c7e;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<h2>CARS IN THE DATABASE :</h2>
<table>
<tr>
<th class="column1">Car_Id</th>
<th class="column2"> Car_name</th>
<th class="column3">Car_No</th>
<th class="column4">Category</th>
<th class="column5">Type</th>
<th class="column6">Rate/km</th>
<th class="column7">Availability</th>
</tr>
<?php
    $conn = OpenCon();
    $sql = "SELECT * FROM car";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["Car_id"]. "</td><td>" . $row["Car_name"] . "</td><td>". $row["Car_no"]. "</td><td>" . $row["category"]. "</td><td>" . $row["type"]. "</td><td>" . $row["rate_per_km"]. "</td><td>" . $row["availability"]. "</td></tr>";}
            echo "</table>";
        }   
        else { echo "0 results"; }
        CloseCon($conn);
?>
</table>
</body>
</html>