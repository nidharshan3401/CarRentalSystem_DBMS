<?php
    include 'db_connection.php';
    $s = session_name ("loggedin1");
    session_start();
    // Check if the user is logged in, if not then redirect him to login page
        if(!isset($_SESSION["loggedin1"]) || $_SESSION["loggedin1"] !== true){
        header("location: Adminlogin.php");
        exit;}
?>
<!DOCTYPE html>
<html>
<head>
<title>Drivers</title>
<style>
table {
border-collapse: collapse;
width: 100%;
color: #ce4949;
font-family: monospace;
font-size: 25px;
text-align: left;
}
th {
background-color: #ce4949;
color: white;
}
tr:nth-child(even) {background-color: #f2f2f2}
</style>
</head>
<body>
<h2>DRIVERS IN THE DATABASE :</h2>
<table>
<tr>
<th>Id</th>
<th>Adhar</th>
<th>Name</th>
<th>Mobile No</th>
<th>Experience</th>
<th>Availability</th>
</tr>
<?php
    $conn = OpenCon();
    $sql = "SELECT driver.Driver_id,driver.Adhar_id,driver_person.Name,driver_person.Address,driver.experience,driver.availability,driver_mobile.Mobile_no FROM driver INNER JOIN driver_person ON driver.Adhar_id=driver_person.Adhar_id INNER JOIN driver_mobile ON driver.Adhar_id=driver_mobile.Adhar_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["Driver_id"]. "</td><td>" . $row["Adhar_id"] . "</td><td>". $row["Name"]. "</td><td>" . $row["Mobile_no"]. "</td><td>" . $row["experience"]. "</td><td>" . $row["availability"]. "</td></tr>";}
            echo "</table>";
        }   
        else { echo "0 results"; }
        CloseCon($conn);
?>
</table>
</body>
</html>